<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Cate_code=$_REQUEST['Cate_code'];
	$Cate_name=$_REQUEST['Cate_name'];

$result1=mysql_query("SELECT Cate_code from category where Cate_code='$Cate_code'");
$row1=mysql_fetch_array($result1);

if($row1!=0){
	
$query="UPDATE `category` SET `Cate_code`='$Cate_code',`Cate_name`='$Cate_name' WHERE Cate_code='$Cate_code'";
$result=mysql_query($query) or die(mysql_error());


echo "Data UPDATED Succesfully!!!";

$var=mysql_query("select * from category");
echo "<table border size=1>";
echo "<tr><th>category Cate_code</th> <th>category Cate_name</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td>";
}

}else{
echo "Invalid CATEGORY CODE!!!!";

}
?>
</body>
</html>