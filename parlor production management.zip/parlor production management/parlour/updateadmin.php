<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$admin_id=$_REQUEST['admin_id'];
	$Admin_name=$_REQUEST['Admin_name'];
	$Admin_password=$_REQUEST['Admin_password'];

$result1=mysql_query("SELECT admin_id from admin where admin_id='$admin_id'");
$row1=mysql_fetch_array($result1);

if($row1!=0){

$query="UPDATE `admin` SET `admin_id`='$admin_id',`Admin_name`='$Admin_name',`Admin_password`='$Admin_password' WHERE admin_id='$admin_id'";
$result=mysql_query($query) or die(mysql_error());

echo "Data update succesfully!!!";

$var=mysql_query("select * from admin");
echo "<table border size=1>";
echo "<tr> <th>Admin_id</th> <th>admin Admin_name</th> <th>admin Admin_password</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td></tr>";
}
}else{
echo "Invalid admin id!!!!";
}


?>
</body>
</html>