<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());

$admin_id=$_REQUEST['admin_id'];

$result1=mysql_query("SELECT admin_id from admin where admin_id='$admin_id'");
$row1=mysql_fetch_array($result1);

if($row1!=0){


$query="delete from admin where admin_id='$admin_id'";
$result=mysql_query($query) or die(mysql_error());
echo "data deleted successfully!!!!";

$var=mysql_query("SELECT * from admin");
echo"<table border size=1>";
echo"<tr> <th>Admin_id</th><th>Admin_name</th> <th>Admin_password</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td><td>$arr[2]</td></tr>";
}
echo"</table>";

}else{
echo "Invalid ADMIN_ID!!!!";

}


?>
<h4><font color="cyan"><a href="admindb.html">click here to go back to the home page </a></font></h4>
</body>
</html>