<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Supp_id=$_REQUEST['Supp_id'];
	$Supp_name=$_REQUEST['Supp_name'];
	$Supp_add=$_REQUEST['Supp_add'];
	$Supp_area=$_REQUEST['Supp_area'];
	$Supp_city=$_REQUEST['Supp_city'];
	$Supp_pincode=$_REQUEST['Supp_pincode'];
	$Supp_phno=$_REQUEST['Supp_phno'];

$result1=mysql_query("SELECT Supp_id from supplier where Supp_id='$Supp_id'");
$row1=mysql_fetch_array($result1);

if($row1!=0){

$query="UPDATE `supplier` SET `Supp_id`='$Supp_id',`Supp_name`='$Supp_name',`Supp_add`='$Supp_add',`Supp_area`='$Supp_area',`Supp_city`='$Supp_city',`Supp_pincode`='$Supp_pincode',`Supp_phno`='$Supp_phno' WHERE Supp_id='$Supp_id'";
$result=mysql_query($query) or die(mysql_error());



echo "Data updated succesfully!!!";

$var=mysql_query("select * from supplier ");
echo "<table border size=1>";
echo "<tr><th>supplier Supp_id</th> <th>supplier Supp_name</th> <th>supplier Supp_add</th> <th>supplier Supp_area</th> <th>supplier Supp_city</th> <th>supplier Supp_pincode</th> <th>supplier Supp_phno</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td>";
}
}else{
echo "Invalid Supplier id!!!!";
}

?>
</body>
</html>