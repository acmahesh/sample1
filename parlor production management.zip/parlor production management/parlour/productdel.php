<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());

$Prod_code=$_REQUEST['Prod_code'];

$result1=mysql_query("SELECT Prod_code from product where Prod_code='$Prod_code'");
$row1=mysql_fetch_array($result1);

if($row1!=0){

$query="delete from product where Prod_code='$Prod_code'";
$result=mysql_query($query) or die(mysql_error());
echo "data deleted successfully!!!!";

$var=mysql_query("SELECT * from product");
echo"<table border size=1>";
echo"<tr><th>Prod_code</th> <th> Prod_name</th> <th>Cate_code</th> <th>Prod_price</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td> </tr>";
}
echo"</table>";

}else{
echo "Invalid PRODUCT CODE!!!!";

}

?>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
</body>
</html>