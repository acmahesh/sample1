<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Cust_id=$_REQUEST['Cust_id'];
	$Cust_name=$_REQUEST['Cust_name'];
	$Cust_add=$_REQUEST['Cust_add'];
	$Cust_area=$_REQUEST['Cust_area'];
	$Cust_city=$_REQUEST['Cust_city'];
	$Cust_phno=$_REQUEST['Cust_phno'];
	$Cust_paid=$_REQUEST['Cust_paid'];
	$Cust_due=$_REQUEST['Cust_due'];
$query="INSERT INTO customer VALUES('$Cust_id','$Cust_name','$Cust_add','$Cust_area','$Cust_city','$Cust_phno','$Cust_paid','$Cust_due')";
$result=mysql_query($query) or die(mysql_error());

echo "Data inserted succesfully!!!";

$var=mysql_query("select * from customer ");
echo "<table border size=1>";
echo "<tr><th>customer Cust_id</th> <th>customer Cust_name</th> <th>customer Cust_add</th> <th>customer Cust_area</th> <th>customer Cust_city</th> <th>customer Cust_phno</th> <th>customer Cust_paid</th> <th>customer Cust_due</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td><td>$arr[7]</td>";
}

?>
</body>
</html>