<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());


$var=mysql_query("SELECT * from purchase");
echo"<table border size=1>";
echo"<tr><th>Purch_code</th> <th> Purch_date</th> <th>Supp_id</th> <th>Prod_code</th><th>Prod_price</th><th>Quantity</th><th>Purch_remark</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td> </tr>";
}
echo"</table>";

?>
<h4><font color="cyan"><a href="purchasedb.html">click here to go back to the home page </a></font></h4>
</body>
</html>