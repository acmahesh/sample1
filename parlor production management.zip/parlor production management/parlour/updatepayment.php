<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Payment_code=$_REQUEST['Payment_code'];
	$Payment_date=$_REQUEST['Payment_date'];
	$Cust_id=$_REQUEST['Cust_id'];
        $Amount=$_REQUEST['Amount'];


$result1=mysql_query("SELECT Payment_code from payment where Payment_code='$Payment_code'");
$row1=mysql_fetch_array($result1);

if($row1!=0){


	
$query="UPDATE `payment` SET `Payment_code`='$Payment_code',`Payment_date`='$Payment_date',`Cust_id`='$Cust_id',`Amount`='$Amount' WHERE Payment_code='$Payment_code'";
$result=mysql_query($query) or die(mysql_error());

echo "Data update succesfully!!!";

$var=mysql_query("select * from payment");
echo "<table border size=1>";
echo "<tr><th>payment Payment_code</th> <th>payment Payment_date</th> <th>payment Cust_id</th> <th>payment Amount</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td>";
}
}else{
echo "Invalid Payment code!!!!";
}


?>
</body>
</html>