<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());

$Supp_id=$_REQUEST['Supp_id'];

$result1=mysql_query("SELECT Supp_id from supplier where Supp_id='$Supp_id'");
$row1=mysql_fetch_array($result1);

if($row1!=0){


$query="delete from supplier where Supp_id='$Supp_id'";
$result=mysql_query($query) or die(mysql_error());
echo "data deleted successfully!!!!";

$var=mysql_query("SELECT * from supplier");
echo"<table border size=1>";
echo"<tr><th>Supp_id</th> <th> Supp_name</th> <th>Supp-add</th> <th>Supp_area</th> <th>Supp_city</th> <th>Supp_pincode</th> <th>Supp_phno</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td> </tr>";
}
echo"</table>";

}else{
echo "Invalid SUPPLIER ID!!!!";

}

?>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
</body>
</html>