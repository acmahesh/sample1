<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());

$var=mysql_query("SELECT * from admin");
echo"<table border size=1>";
echo"<tr> <th> Admin_name</th> <th>Admin_password</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td></tr>";
}
echo"</table>";

?>
<h4><font color="cyan"><a href="admindb.html">click here to go back to the home page </a></font></h4>
</body>
</html>