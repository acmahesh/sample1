
<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Prod_code=$_REQUEST['Prod_code'];
	$Prod_name=$_REQUEST['Prod_name'];
	$Cate_code=$_REQUEST['Cate_code'];
        $Prod_price=$_REQUEST['Prod_price'];
	
$query="INSERT INTO product VALUES('$Prod_code','$Prod_name','$Cate_code','$Prod_price')";
$result=mysql_query($query) or die(mysql_error());

echo "Data inserted succesfully!!!";

$var=mysql_query("select * from product");
echo "<table border size=1>";
echo "<tr><th>product Prod_code</th> <th>product Prod_name</th> <th>product Cate_code</th> <th>product Prod_price</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td>";
}


?>
</body>
</html>