<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());

$var=mysql_query("SELECT * from customer");
echo"<table border size=1>";
echo"<tr><th>Cust_id</th> <th> Cust_name</th> <th>Cust_add</th> <th>Cust_area</th><th>Cust_city</th><th>Cust_phno</th><th>Cust_paid</th><th>Cust_due</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td><td>$arr[7]</td> </tr>";
}
echo"</table>";

?>
<h4><font color="cyan"><a href="customerdb.html">click here to go back to the home page </a></font></h4>
</body>
</html>