<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Payment_code=$_REQUEST['Payment_code'];
	$Payment_date=$_REQUEST['Payment_date'];
	$Cust_id=$_REQUEST['Cust_id'];
        $Amount=$_REQUEST['Amount'];
	$GST=Null;
	
$query="INSERT INTO payment VALUES('$Payment_code','$Payment_date','$Cust_id','$Amount','$GST')";
$result=mysql_query($query) or die(mysql_error());

echo "Data inserted succesfully!!!";

$var=mysql_query("select * from payment");
echo "<table border size=1>";
echo "<tr><th>payment Payment_code</th> <th>payment Payment_date</th> <th>payment Cust_id</th> <th>payment Amount</th> <th>payment GST</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td></tr>";
}
echo"</table>";
?>
<?php
mysql_select_db('products') or die(mysql_error());
$p0=mysql_query("call total(@out)");
$rs=mysql_query('SELECT @out');
while($row=mysql_fetch_row($rs))
{
	echo 'total=' .$row[0];
}


?>
</body>
</html>