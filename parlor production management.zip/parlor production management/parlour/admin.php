<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$admin_id=$_REQUEST['admin_id'];
	$Admin_name=$_REQUEST['Admin_name'];
	$Admin_password=$_REQUEST['Admin_password'];

$query="INSERT INTO admin VALUES('$admin_id','$Admin_name','$Admin_password')";
$result=mysql_query($query) or die(mysql_error());

echo "Data inserted succesfully!!!";

$var=mysql_query("select * from admin");
echo "<table border size=1>";
echo "<tr> <th>Admin_id</th> <th>admin Admin_name</th> <th>admin Admin_password</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td></tr>";
}

?>
</body>
</html>