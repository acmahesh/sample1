<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Purch_code=$_REQUEST['Purch_code'];
	$Purch_date=$_REQUEST['Purch_date'];
	$Supp_id=$_REQUEST['Supp_id'];
	$Prod_code=$_REQUEST['Prod_code'];
	$Prod_price=$_REQUEST['Prod_price'];
	$Quantity=$_REQUEST['Quantity'];
	$Purch_remark=$_REQUEST['Purch_remark'];
$query="INSERT INTO purchase VALUES('$Purch_code','$Purch_date','$Supp_id','$Prod_code','$Prod_price','$Quantity','$Purch_remark')";
$result=mysql_query($query) or die(mysql_error());

echo "Data inserted succesfully!!!";

$var=mysql_query("select * from purchase ");
echo "<table border size=1>";
echo "<tr><th>purchase Purch_code</th> <th>purchase Purch_date</th> <th>purchase Supp_id</th> <th>purchase Prod_code</th> <th>purchase Prod_price</th> <th>purchase Quantity</th> <th>purchase Purch_remark</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td></tr>";
}

?>
</body>
</html>