<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Cate_code=$_REQUEST['Cate_code'];
	$Cate_name=$_REQUEST['Cate_name'];
	
$query="INSERT INTO category VALUES('$Cate_code','$Cate_name')";
$result=mysql_query($query) or die(mysql_error());

echo "Data inserted succesfully!!!";

$var=mysql_query("select * from category");
echo "<table border size=1>";
echo "<tr><th>category Cate_code</th> <th>category Cate_name</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td>";
}
?>
</body>
</html>