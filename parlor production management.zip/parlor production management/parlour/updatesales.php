<html>
<body>
<?php

	$dbh=mysql_connect('localhost','root','') or die (mysql_error());
	mysql_select_db('products') or die(mysql_error());
	
	$Sales_code=$_REQUEST['Sales_code'];
	$Sales_date=$_REQUEST['Sales_date'];
	$Cust_id=$_REQUEST['Cust_id'];
	$Prod_code=$_REQUEST['Prod_code'];
	$Prod_price=$_REQUEST['Prod_price'];
	$Quantity=$_REQUEST['Quantity'];
	$Total_amount=$_REQUEST['Total_amount'];
	$Paid_amount=$_REQUEST['Paid_amount'];
	$Sales_remark=$_REQUEST['Sales_remark'];

$result1=mysql_query("SELECT Sales_code from sales where Sales_code='$Sales_code'");
$row1=mysql_fetch_array($result1);

if($row1!=0){



$query="UPDATE `sales` SET `Sales_code`='$Sales_code',`Sales_date`='$Sales_date',`Cust_id`='$Cust_id',`Prod_code`='$Prod_code',`Quantity`='$Quantity',`Total_amount`='$Total_amount',`Paid_amount`='$Paid_amount',`Sales_remark`='$Sales_remark'  WHERE Sales_code='$Sales_code'";
$result=mysql_query($query) or die(mysql_error());


echo "Data updated succesfully!!!";

$var=mysql_query("select * from sales ");
echo "<table border size=1>";
echo "<tr><th>sales Sales_code</th> <th>sales Sales_date</th> <th>sales Cust_id</th> <th>sales Prod_code</th> <th>sales Prod_price</th> <th>sales Quantity</th> <th>sales Total_amount</th> <th>sales Paid_amount</th> <th>sales Sales_remark</th>";
while ($arr=mysql_fetch_row($var))
{
	echo "<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td><td>$arr[6]</td><td>$arr[7]</td><td>$arr[8]</td>";
}
}else{
echo "Invalid Sales code!!!!";
}

?>
</body>
</html>