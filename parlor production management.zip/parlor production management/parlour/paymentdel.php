<html>
<body >
<?php
$dbh=mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('products') or die (mysql_error());

$Payment_code=$_REQUEST['Payment_code'];


$result1=mysql_query("SELECT Payment_code from payment where Payment_code='$Payment_code'");
$row1=mysql_fetch_array($result1);

if($row1!=0){


$query="delete from payment where Payment_code='$Payment_code'";
$result=mysql_query($query) or die(mysql_error());
echo "data deleted successfully!!!!";

$var=mysql_query("SELECT * from payment");
echo"<table border size=1>";
echo"<tr><th>Payment_code</th> <th> Payment_date</th> <th>Cust_id</th> <th>Amount</th><th>Pay_remark</th></tr>";
while ($arr=mysql_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td> </tr>";
}
echo"</table>";

}else{
echo "Invalid PAYMENT CODE!!!";

}

?>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
</body>
</html>