-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2017 at 12:07 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `total` (OUT `total` INT)  NO SQL
select sum(Amount) into total from payment$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `Admin_name` varchar(15) NOT NULL,
  `Admin_password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `Admin_name`, `Admin_password`) VALUES
(1, 'Supraja', '1234'),
(2, 'Saanvi', '12348');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Cate_code` int(6) NOT NULL,
  `Cate_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Cate_code`, `Cate_name`) VALUES
(2222, 'suhas'),
(3333, 'Butter'),
(5555, 'Curd'),
(6666, 'Ice-cream');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Cust_id` int(6) NOT NULL,
  `Cust_name` varchar(15) NOT NULL,
  `Cust_add` varchar(10) NOT NULL,
  `Cust_area` varchar(10) NOT NULL,
  `Cust_city` varchar(10) NOT NULL,
  `Cust_phno` varchar(10) DEFAULT NULL,
  `Cust_paid` int(6) NOT NULL,
  `Cust_due` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cust_id`, `Cust_name`, `Cust_add`, `Cust_area`, `Cust_city`, `Cust_phno`, `Cust_paid`, `Cust_due`) VALUES
(0, '', '', '', '', '', 0, 0),
(201, 'Sharvith', 'vijaynagar', 'tumkur', 'tumkur', '7654323415', 50, 0),
(203, 'Soumya', 'chamarajna', 'mysore', 'mysore', '7980654321', 60, 10),
(204, 'Sneha', 'mg road', 'Shivmoga', 'Shivmoga', '8907654321', 30, 0),
(205, 'Prathik', 'Basavangud', 'Bangalore', 'Bangalore', '8951094456', 100, 20);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_code` int(6) NOT NULL,
  `Payment_date` varchar(15) DEFAULT NULL,
  `Cust_id` int(6) DEFAULT NULL,
  `Amount` int(6) NOT NULL,
  `GST` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_code`, `Payment_date`, `Cust_id`, `Amount`, `GST`) VALUES
(10001, '30-feb-17', 203, 300, 222),
(10008, '20-jul-17', 204, 100, 112),
(10014, '20-jul-17', 203, 120, 134),
(10110, '24-jun-17', 203, 100, 112),
(11111, '8-apr-17', 204, 50, 56),
(11112, '8-apr-17', 204, 50, 56),
(101112, '24-jun-17', 203, 100, 112);

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `GST` BEFORE INSERT ON `payment` FOR EACH ROW set new.GST=(new.Amount)+(new.Amount)*0.12
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Prod_code` int(6) NOT NULL,
  `Prod_name` varchar(15) NOT NULL,
  `Cate_code` int(6) DEFAULT NULL,
  `Prod_price` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Prod_code`, `Prod_name`, `Cate_code`, `Prod_price`) VALUES
(0, 'Good life', 5555, 60),
(141, 'Arun', 2222, 46),
(161, 'Milky Mist', 3333, 40);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `Purch_code` int(6) NOT NULL,
  `Purch_date` varchar(12) DEFAULT NULL,
  `Supp_id` int(6) DEFAULT NULL,
  `Prod_code` int(6) DEFAULT NULL,
  `Prod_price` int(6) NOT NULL,
  `Quantity` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`Purch_code`, `Purch_date`, `Supp_id`, `Prod_code`, `Prod_price`, `Quantity`) VALUES
(1004, '24-apr-17', 104, 141, 50, '4');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `Sales_code` int(6) NOT NULL,
  `Sales_date` varchar(15) DEFAULT NULL,
  `Cust_id` int(6) DEFAULT NULL,
  `Prod_code` int(6) DEFAULT NULL,
  `Prod_price` int(6) NOT NULL,
  `Quantity` varchar(8) NOT NULL,
  `Total_amount` int(6) NOT NULL,
  `Paid_amount` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Sales_code`, `Sales_date`, `Cust_id`, `Prod_code`, `Prod_price`, `Quantity`, `Total_amount`, `Paid_amount`) VALUES
(8883, '02-feb-17', 204, 0, 100, '2', 70, 70),
(8885, '30-apr-17', 203, 141, 100, '5', 200, 150);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `Supp_id` int(6) NOT NULL,
  `Supp_name` varchar(15) NOT NULL,
  `Supp_add` varchar(10) NOT NULL,
  `Supp_area` varchar(10) NOT NULL,
  `Supp_city` varchar(10) NOT NULL,
  `Supp_pincode` int(7) NOT NULL,
  `Supp_phno` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`Supp_id`, `Supp_name`, `Supp_add`, `Supp_area`, `Supp_city`, `Supp_pincode`, `Supp_phno`) VALUES
(101, 'suhas', 'jaynagar', 'Tumkur', 'Tumkur', 562102, '9088155467'),
(102, 'Srujan', 'rajajinaga', 'bangalore', 'bangalore', 556789, '9035640891'),
(103, 'Sandeep', 'vijaynagar', 'mysore', 'mysore', 5546789, '9088155467'),
(104, 'shreya', 'yeshwanthp', 'bangalore', 'bangalore', 556789, '7896543210'),
(105, 'sindu', 'malleshwar', 'bangalore', 'bangalore', 556789, '9876543210');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Cate_code`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Cust_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_code`),
  ADD KEY `Cust_id` (`Cust_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Prod_code`),
  ADD KEY `Cate_code` (`Cate_code`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`Purch_code`),
  ADD KEY `Supp_id` (`Supp_id`),
  ADD KEY `Prod_code` (`Prod_code`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`Sales_code`),
  ADD KEY `Cust_id` (`Cust_id`),
  ADD KEY `Prod_code` (`Prod_code`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`Supp_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Cust_id`) REFERENCES `customer` (`Cust_id`) ON DELETE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`Cate_code`) REFERENCES `category` (`Cate_code`) ON DELETE CASCADE;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `purchase_ibfk_1` FOREIGN KEY (`Supp_id`) REFERENCES `supplier` (`Supp_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchase_ibfk_2` FOREIGN KEY (`Prod_code`) REFERENCES `product` (`Prod_code`) ON DELETE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`Cust_id`) REFERENCES `customer` (`Cust_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`Prod_code`) REFERENCES `product` (`Prod_code`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
